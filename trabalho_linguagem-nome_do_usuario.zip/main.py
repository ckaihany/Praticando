import datetime              #Módulo da Biblioteca
from datetime import date  # classe date

#Cabeçalho
print("="*16)
print ('CÁLCULO DE IDADE')
print("="*16)

#Entrada de dados
nome = input("Nome: ")
dia = int(input("Nasceu em que dia? "))
mes = int(input("Nasceu em que mes? "))
ano = int(input("Nasceu em que ano? "))

#diferença entre Data Atual e Data de Nascimento
dataNasc = datetime.date(ano, mes, dia)
diferenca = (date.today()- dataNasc)

#Cáculos e Resultados
result =(diferenca.days / 365.25)

#Formata string, onde %d torna o número inteiro
print('%s tem %d anos'% (nome, result))